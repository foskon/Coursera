//
//  LabelRow.swift
//  PizzaCreator
//
//  Created by Carlos Manzanas on 01/10/16.
//  Copyright © 2016 Carlos Manzanas. All rights reserved.
//

import WatchKit

class LabelRow: NSObject {
    
    @IBOutlet weak var rowLabel: WKInterfaceLabel!
    
}
