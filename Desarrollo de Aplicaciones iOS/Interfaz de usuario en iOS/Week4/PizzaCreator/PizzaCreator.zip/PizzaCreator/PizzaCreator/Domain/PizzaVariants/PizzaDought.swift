//
// Created by Carlos Manzanas on 18/09/16.
// Copyright (c) 2016 Carlos Manzanas. All rights reserved.
//

import Foundation

struct PizzaDought {
    let title: String

    init(title: String) {
        self.title = title
    }
}