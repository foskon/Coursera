//
//  SongCell.swift
//  reproductor
//
//  Created by Carlos Manzanas on 26/03/17.
//  Copyright © 2017 foskon. All rights reserved.
//

import UIKit

class SongCell: UITableViewCell {
    
    static let identifier = "cell"
    
    var songId: String!
}
